// Engine_WeatherBell
// a subtractive, multi-octave drone-bell voice for the "weatherbell"
// norns script. structure mirrors Engine_Synapse (confirmed working):
// voice writes to a private intermediate bus, a separate output-stage
// synth (added via Synth.tail on context.xg) reads that bus and
// writes to context.out_b.
//
// layers: two sub-bass octaves (saw-based, "brassy"), a saw-based
// root, and two clean sine octaves above. the two upper sine octaves
// fade in/out with a "daytime" control (0=night, 1=day) -- fuller,
// more open harmonic spread by day; collapses toward the low,
// brassy fundamental register at night.

Engine_WeatherBell : CroneEngine {
	var pg;
	var voiceBus;
	var voice;
	var outStage;

	var pitch = 55;
	var cutoff = 1200;
	var resonance = 0.2;
	var lfoRate = 0.08;
	var lfoDepth = 400;
	var noiseAmt = 0.0;
	var daytime = 0.5;
	var ampLfoMult = 1.0;
	var moonThrob = 0.0;
	var windNoiseMix = 0.0;
	var windSpeed = 0.0;
	var droneLevel = 1.0;
	var noiseLevel = 1.0;
	var glideTime = 3.0;
	var amp = 0.5;

	// pluck voice (precipitation-driven melody) -- "current state" set
	// via commands before each trigger, same pattern as Engine_Synapse
	var pluckAmp = 0.3;
	var pluckDecay = 1.0;
	var pluckCoef = 0.15;
	var pluckStrike = 0.01;
	var pluckPan = 0.0;

	*new { arg context, doneCallback;
		^super.new(context, doneCallback);
	}

	alloc {
		voiceBus = Bus.audio(context.server, 2);
		pg = ParGroup.tail(context.xg);

		SynthDef("WeatherBellVoice", {
			arg out, pitch = 55, cutoff = 1200, resonance = 0.2,
				lfoRate = 0.08, lfoDepth = 400, noiseAmt = 0.0,
				daytime = 0.5, ampLfoMult = 1.0, moonThrob = 0.0,
				windNoiseMix = 0.0, windSpeed = 0.0, droneLevel = 1.0,
				noiseLevel = 1.0, glideTime = 3.0, amp = 0.5;
			var pitchL, cutoffL, resL, lfoRateL, lfoDepthL, noiseAmtL,
				daytimeL, ampLfoMultL, moonThrobL, windNoiseMixL,
				windSpeedL, droneLevelL, noiseLevelL, glideTimeL, ampL;
			var sub2, sub1, root, oct1, oct2, bellPartial, noise;
			var daySub, dayRoot, dayOct1, dayOct2, dayBell;
			var sig, lfo, cutoffMod;
			var ad2, ad1, adR, adO1, adO2;
			var throbTrig, throbEnv;
			var windGustTrig, windGustEnv;
			var windBodyDrift, windBodyCutoff, windBody, windWhistle;
			var windLayer, windDelay;

			// lag every incoming parameter so weather updates feel like
			// a slow drift, not a jump. daytime lags especially slowly,
			// since day/night is itself a slow drift.
			// weather-driven parameters glide over minutes, not seconds --
			// pitch (a deliberate, infrequent manual edit) and amp
			// (an immediate performance control) stay fast
			glideTimeL = Lag.kr(glideTime, 4);
			pitchL = Lag.kr(pitch, glideTimeL);
			cutoffL = Lag.kr(cutoff, 100);
			resL = Lag.kr(resonance, 100);
			lfoRateL = Lag.kr(lfoRate, 70);
			lfoDepthL = Lag.kr(lfoDepth, 70);
			noiseAmtL = Lag.kr(noiseAmt, 70);
			daytimeL = Lag.kr(daytime, 30);
			ampLfoMultL = Lag.kr(ampLfoMult, 70);
			moonThrobL = Lag.kr(moonThrob, 30);
			windNoiseMixL = Lag.kr(windNoiseMix, 80);
			windSpeedL = Lag.kr(windSpeed, 80);
			droneLevelL = Lag.kr(droneLevel, 2);
			noiseLevelL = Lag.kr(noiseLevel, 2);
			ampL = Lag.kr(amp, 2);

			// per-layer amplitude, driven by time of day (0=night, 1=day)
			daySub = 0.35 + ((1 - daytimeL) * 0.15);   // slightly fuller at night
			dayRoot = 0.35;                              // always the anchor
			dayOct1 = daytimeL * 0.25;                   // fades in by day
			dayOct2 = daytimeL.squared * 0.15;            // concentrated near midday
			dayBell = 0.04 + (daytimeL * 0.05);

			// each layer swells independently at its own slow,
			// non-synchronized rate, so the ensemble keeps gently
			// animating and (for all practical purposes) never repeats.
			// (pitch-drift wobble was removed -- it read as "bubbly"
			// rather than graceful, so pitch now stays rock-steady.)
			ad2 = SinOsc.kr(0.009 * ampLfoMultL).range(0.8, 1.0);
			ad1 = SinOsc.kr(0.013 * ampLfoMultL).range(0.8, 1.0);
			adR = SinOsc.kr(0.017 * ampLfoMultL).range(0.85, 1.0);
			adO1 = SinOsc.kr(0.021 * ampLfoMultL).range(0.75, 1.0);
			adO2 = SinOsc.kr(0.026 * ampLfoMultL).range(0.7, 1.0);

			// low register: single oscillators (no detuned pairs -- that
			// constant beating was a big source of the "impure" sound),
			// mostly sine with just a touch of saw blended in for warmth
			// rather than full harmonic buzz
			sub2 = ((SinOsc.ar(pitchL * 0.25) * 0.8)
				+ (Saw.ar(pitchL * 0.25) * 0.2)) * daySub * ad2;
			sub1 = ((SinOsc.ar(pitchL * 0.5) * 0.8)
				+ (Saw.ar(pitchL * 0.5) * 0.2)) * daySub * ad1;
			root = ((SinOsc.ar(pitchL) * 0.75)
				+ (Saw.ar(pitchL) * 0.25)) * dayRoot * adR;

			// upper register: clean sine octaves, fade in by day for an
			// open, spacious spread
			oct1 = SinOsc.ar(pitchL * 2) * dayOct1 * adO1;
			oct2 = SinOsc.ar(pitchL * 4) * dayOct2 * adO2;
			bellPartial = SinOsc.ar(pitchL * 2.76) * dayBell;

			noise = PinkNoise.ar(1) * noiseAmtL;

			// occasional low-end throb, governed by moon phase: sparse,
			// randomly-timed pulses (not a metronomic lfo) whose
			// frequency and depth both scale with how full the moon is
			// sparser, quieter, and much slower than before -- a rare,
			// gradual swell rather than a pulse. density and depth both
			// still scale with how full the moon is.
			throbTrig = Dust.kr((0.0015 + (moonThrobL * 0.012)).max(0.0003));
			throbEnv = EnvGen.kr(Env.perc(20, 35), throbTrig) * moonThrobL;
			sub2 = sub2 * (1 + (throbEnv * 0.25));
			sub1 = sub1 * (1 + (throbEnv * 0.25));

			// wind, redesigned: a drifting-filter noise bed (smooth
			// random-walk cutoff, not a periodic lfo -- like wind
			// moving slowly across varied terrain) plus a separate,
			// stochastic gust layer. gusts are randomly-timed events,
			// each briefly pushing both brightness and volume up
			// before settling back, with a thin high whistle that
			// only emerges during the gust itself. overall loudness
			// tracks wind speed throughout.
			windGustTrig = Dust.kr(0.015 + ((windSpeedL / 50).clip(0, 1) * 0.08));
			windGustEnv = EnvGen.kr(Env.perc(0.7, 3.5), windGustTrig);

			windBodyDrift = LFNoise2.kr(0.012).range(-300, 300);
			windBodyCutoff = (250 + ((windSpeedL / 50).clip(0, 1) * 900)
				+ windBodyDrift + (windGustEnv * 2200)).clip(120, 5000);
			windBody = BPF.ar(PinkNoise.ar(1), windBodyCutoff, 1.3);

			windWhistle = HPF.ar(WhiteNoise.ar(1), 2500) * windGustEnv * 0.5;

			windLayer = ((windBody * 0.8) + windWhistle)
				* (0.12 + ((windSpeedL / 50).clip(0, 1) * 0.6)) * windNoiseMixL;

			// gentle delay for some spatial diffusion
			windDelay = CombL.ar(windLayer, 1.0, 0.42, 3.5);
			windLayer = (windLayer * 0.65) + (windDelay * 0.5);

			// drone (oscillator layers) and noise (precipitation texture +
			// wind bands) get independent user levels, both still
			// passing through the shared filter/master stage below
			sig = ((sub2 + sub1 + root + oct1 + oct2 + bellPartial) * droneLevelL)
				+ ((noise + windLayer) * noiseLevelL);

			lfo = SinOsc.kr(lfoRateL).range(-1, 1) * lfoDepthL;
			cutoffMod = (cutoffL + lfo).clip(60, 8000);

			sig = RLPF.ar(sig, cutoffMod, (1 - resL).clip(0.05, 1));
			sig = sig * ampL;
			Out.ar(out, Pan2.ar(sig, 0));
		}).add;

		// precipitation-driven melody voice: karplus-strong pluck,
		// adapted from the proven Engine_Synapse voice design. each
		// trigger spawns its own short-lived, self-terminating synth,
		// so overlapping notes just work.
		SynthDef("WeatherBellPluck", {
			arg out, freq = 440, amp = 0.3, decaytime = 1.0, coef = 0.15,
				strike = 0.01, pan = 0.0;
			var trig, burstEnv, burst, snd1, snd2, snd, ampEnv;
			trig = Impulse.kr(0);
			burstEnv = EnvGen.ar(Env.perc(0.0005, strike, 1, -4), trig);
			// excitation noise burst goes straight into Pluck unfiltered --
			// no LPF stage ahead of it, so pluckCoef/decaytime alone shape
			// the tone rather than an extra cutoff also coloring it
			burst = WhiteNoise.ar(amp) * burstEnv;
			// piano-like unison: real piano notes ring two or three
			// strings tuned a hair apart, which beat gently against
			// each other for a thicker, slightly shimmering body
			// instead of one pure karplus-strong string
			snd1 = Pluck.ar(
				in: burst, trig: trig, maxdelaytime: 0.05,
				delaytime: freq.reciprocal, decaytime: decaytime,
				coef: coef.clip(-0.9, 0.9)
			);
			snd2 = Pluck.ar(
				in: burst, trig: trig, maxdelaytime: 0.05,
				delaytime: (freq * 1.003).reciprocal, decaytime: decaytime * 0.92,
				coef: coef.clip(-0.9, 0.9)
			);
			snd = (snd1 * 0.7) + (snd2 * 0.5);
			// piano-like two-stage amplitude envelope: a quick initial
			// dip right after the hammer strike, as the upper partials
			// shed fast, settling into a longer, slower-decaying body --
			// rather than one uniform linear decay
			ampEnv = EnvGen.kr(
				Env.new(
					[0, 1, 0.55, 0],
					[0.001, decaytime * 0.25, decaytime * 0.75],
					[-2, -4, -4]
				),
				doneAction: 2
			);
			snd = LeakDC.ar(snd) * ampEnv;
			Out.ar(out, Pan2.ar(snd, pan));
		}).add;

		// deep bell strike: classic 5-partial additive bell model (hum,
		// prime, tierce, quint, nominal) plus a bright, fast-decaying
		// "clang" partial for the initial metallic strike transient.
		// each partial rings out at its own natural decay rate.
		SynthDef("WeatherBellStrike", {
			arg out, freq = 130, amp = 0.5;
			var trig, humEnv, primeEnv, tierceEnv, quintEnv, nominalEnv, clangEnv;
			var sig;
			trig = Impulse.kr(0);
			humEnv = EnvGen.ar(Env.perc(0.005, 8.0), trig, doneAction: 2);
			primeEnv = EnvGen.ar(Env.perc(0.002, 6.0), trig);
			tierceEnv = EnvGen.ar(Env.perc(0.002, 4.0), trig);
			quintEnv = EnvGen.ar(Env.perc(0.002, 3.0), trig);
			nominalEnv = EnvGen.ar(Env.perc(0.001, 2.5), trig);
			clangEnv = EnvGen.ar(Env.perc(0.001, 0.4), trig);

			sig = (SinOsc.ar(freq * 0.5) * humEnv * 0.4)
				+ (SinOsc.ar(freq * 1.0) * primeEnv * 0.5)
				+ (SinOsc.ar(freq * 1.19) * tierceEnv * 0.3)
				+ (SinOsc.ar(freq * 1.5) * quintEnv * 0.25)
				+ (SinOsc.ar(freq * 2.0) * nominalEnv * 0.3)
				+ (SinOsc.ar(freq * 4.05) * clangEnv * 0.35);

			sig = sig * amp;
			Out.ar(out, Pan2.ar(sig, 0));
		}).add;

		SynthDef("WeatherBellOut", {
			arg in, out, fxMix = 0.15;
			var dry, verb, delay, wet, sig, fxMixL;
			dry = In.ar(in, 2);
			fxMixL = Lag.kr(fxMix, 0.05);
			verb = FreeVerb2.ar(dry[0], dry[1], 1.0, 0.6, 0.4);
			delay = CombL.ar(dry, 0.5, 0.375, 2.5);
			wet = (verb * 0.6) + (delay * 0.5);
			sig = (dry * (1 - fxMixL)) + (wet * fxMixL);
			Out.ar(out, sig);
		}).add;

		context.server.sync;

		voice = Synth.new("WeatherBellVoice", [
			\out, voiceBus.index,
			\pitch, pitch, \cutoff, cutoff, \resonance, resonance,
			\lfoRate, lfoRate, \lfoDepth, lfoDepth,
			\noiseAmt, noiseAmt, \daytime, daytime,
			\ampLfoMult, ampLfoMult, \moonThrob, moonThrob,
			\windNoiseMix, windNoiseMix, \windSpeed, windSpeed,
			\droneLevel, droneLevel, \noiseLevel, noiseLevel,
			\glideTime, glideTime, \amp, amp
		], target: pg);

		outStage = Synth.tail(context.xg, "WeatherBellOut", [
			\in, voiceBus.index, \out, context.out_b, \fxMix, 0.15
		]);

		this.addCommand("pitch", "f", { arg msg; voice.set(\pitch, msg[1]); });
		this.addCommand("cutoff", "f", { arg msg; voice.set(\cutoff, msg[1]); });
		this.addCommand("resonance", "f", { arg msg; voice.set(\resonance, msg[1]); });
		this.addCommand("lfoRate", "f", { arg msg; voice.set(\lfoRate, msg[1]); });
		this.addCommand("lfoDepth", "f", { arg msg; voice.set(\lfoDepth, msg[1]); });
		this.addCommand("noiseAmt", "f", { arg msg; voice.set(\noiseAmt, msg[1]); });
		this.addCommand("daytime", "f", { arg msg; voice.set(\daytime, msg[1]); });
		this.addCommand("ampLfoMult", "f", { arg msg; voice.set(\ampLfoMult, msg[1]); });
		this.addCommand("moonThrob", "f", { arg msg; voice.set(\moonThrob, msg[1]); });
		this.addCommand("windNoiseMix", "f", { arg msg; voice.set(\windNoiseMix, msg[1]); });
		this.addCommand("windSpeed", "f", { arg msg; voice.set(\windSpeed, msg[1]); });
		this.addCommand("droneLevel", "f", { arg msg; voice.set(\droneLevel, msg[1]); });
		this.addCommand("noiseLevel", "f", { arg msg; voice.set(\noiseLevel, msg[1]); });
		this.addCommand("glideTime", "f", { arg msg; voice.set(\glideTime, msg[1]); });
		this.addCommand("amp", "f", { arg msg; voice.set(\amp, msg[1]); });
		this.addCommand("fxMix", "f", { arg msg; outStage.set(\fxMix, msg[1]); });

		// pluck voice: "hz"-style trigger (spawns a note at the given
		// freq using whatever pluck* state is currently set), plus
		// commands to update that state before the next trigger
		this.addCommand("pluck", "f", { arg msg;
			Synth("WeatherBellPluck", [
				\out, voiceBus.index,
				\freq, msg[1],
				\amp, pluckAmp,
				\decaytime, pluckDecay,
				\coef, pluckCoef,
				\strike, pluckStrike,
				\pan, pluckPan
			], target: pg);
		});
		this.addCommand("pluckAmp", "f", { arg msg; pluckAmp = msg[1]; });
		this.addCommand("pluckDecay", "f", { arg msg; pluckDecay = msg[1]; });
		this.addCommand("pluckCoef", "f", { arg msg; pluckCoef = msg[1]; });
		this.addCommand("pluckStrike", "f", { arg msg; pluckStrike = msg[1]; });
		this.addCommand("pluckPan", "f", { arg msg; pluckPan = msg[1]; });

		// deep bell strike: one-shot trigger, fixed internal amp
		this.addCommand("bellStrike", "f", { arg msg;
			Synth("WeatherBellStrike", [
				\out, voiceBus.index,
				\freq, msg[1],
				\amp, 0.5
			], target: pg);
		});
	}

	free {
		voice.free;
		outStage.free;
		pg.free;
	}
}
