-- Bell Weather
-- v1.3.0
--
-- a subtractive, weather-driven
-- drone bell, riding underneath
-- a precipitation-driven melody:
-- rain plucks snappy notes that
-- roll down the grid like drops
-- on a window; snow plucks
-- gentler notes that drift down
-- and gently accumulate. root
-- pitch is a fixed EDIT setting,
-- the rest drifts with real
-- local weather.
--
-- temperature -> filter cutoff
-- wind        -> lfo rate
--   (filter sweeps) + grid
--   drift direction/speed
-- humidity    -> resonance
--   (cloudiness proxy)
-- precipitation -> noise amount
--   + melody note density
-- moon phase  -> occasional,
--   slow low-end throb
-- time of day -> octave/harmonic
--   spread (fuller by day,
--   brassier/fundamental by
--   night)
--
-- fetches real local weather
-- directly (io.popen -> curl,
-- no ssh/cron), every ~10 min.
--
-- PARAMS > EDIT:
--   location -- auto (looked up
--     once from your network),
--     Watertown, MA, or custom
--     latitude/longitude
--   root note -- set once, not
--     a live performance control
--   precip mode -- auto, or
--     force rain/snow, to preview
--   weather influence
--   output level
--
-- E1: weather influence
-- E2: tempo -- speeds up or slows
--   down the whole thing (melody
--   spacing + drone drift)
--   proportionally
-- E3: reverb + delay mix
-- K2: mute / unmute
-- K3: fetch weather right now
-- K1 held + E2: push cutoff/
--   resonance/lfo rate past their
--   current weather-set value
-- K1 held + E3: output level
-- K1 held + K2: cycle which
--   parameter K1+E2 pushes
-- K1 held + K3: reset all push
--   offsets back to zero

engine.name = "WeatherBell"

local g = grid.connect()

-- switched from wttr.in to open-meteo.com. reasons, in order:
-- (1) wttr.in's %-code format had no way to ask for a rain PROBABILITY
-- at all, only a raw current-precip amount from a coarse hourly/model
-- bucket -- it read 0 for long stretches even during real, active rain
-- nearby (exactly what was seen during a nor'easter). its json feed
-- fixed that (chanceofrain per 3-hour slot) but that's still a fairly
-- coarse, infrequently-regenerated forecast product.
-- (2) open-meteo has no api key, takes lat/lon directly (no geocoding
-- step to get wrong -- "Watertown,MA" was genuinely ambiguous; there's
-- also a Watertown in NY, CT, SD, WI), returns a real hourly
-- precipitation_probability figure matched to an exact timestamp
-- (rather than guessing which 3-hour bucket is "closest"), and for the
-- US it's typically backed by a high-resolution regional model
-- refreshed roughly hourly -- meaningfully more current than a
-- generic global forecast snapshot.
-- these are Watertown, MA's coordinates (42.37083, -71.18333, per
-- Wikipedia's infobox).
local HOME_LAT, HOME_LON = 42.37083, -71.18333

-- where the weather comes from is a PARAMS setting ("location"), so the
-- script plays whoever's sky it's running under:
--   auto        -- look this norns' position up once from its network
--                  (ipinfo.io/loc, no key), falling back to Watertown
--   Watertown   -- the coordinates above
--   custom      -- the "latitude" / "longitude" params
local auto_loc = nil      -- {lat, lon} once looked up
local loc_note = ""       -- shown in the debug view

local function current_latlon()
	local mode = params:get("location")
	if mode == 2 then loc_note = "Watertown, MA"; return HOME_LAT, HOME_LON end
	if mode == 3 then loc_note = "custom"; return params:get("latitude"), params:get("longitude") end
	if not auto_loc then
		local ok, s = pcall(function()
			local f = io.popen("curl -s --max-time 6 https://ipinfo.io/loc")
			local r = f:read("*a")
			f:close()
			return r
		end)
		local la, lo = ((ok and s) or ""):match("^%s*(%-?[%d%.]+),(%-?[%d%.]+)")
		if la then auto_loc = { tonumber(la), tonumber(lo) } end
	end
	if auto_loc then loc_note = "auto"; return auto_loc[1], auto_loc[2] end
	loc_note = "auto failed, using Watertown"
	return HOME_LAT, HOME_LON
end

local function fetch_cmd()
	local lat, lon = current_latlon()
	return "curl -s --max-time 10 'https://api.open-meteo.com/v1/forecast"
		.. string.format("?latitude=%.5f&longitude=%.5f", lat, lon)
		.. "&current=temperature_2m,relative_humidity_2m,precipitation,pressure_msl,wind_speed_10m,wind_direction_10m"
		.. "&hourly=precipitation_probability"
		.. "&temperature_unit=fahrenheit&wind_speed_unit=mph&precipitation_unit=inch"
		.. "&forecast_days=2&timezone=auto'"
end

local weather = {
	temp_f = 60,
	wind_mph = 3,
	humidity = 50,
	precip_chance = 0,     -- 0-100, chance of rain (or snow) in the next few hours
	pressure_hpa = 1013,
}

local last_read_ok = false
local last_read_msg = "no data yet"
local fetching = false
local muted = false
local k1_held = false

-- manual "push" offsets: E2 nudges the currently-selected parameter
-- past its weather-set value; K1+K3 snaps all three back to zero
local PUSH_NAMES = { "cutoff", "resonance", "lfo rate" }
local push_mode = 1
local push_cutoff = 0
local push_resonance = 0
local push_lfoRate = 0

local fetch_loop_id = nil
local anim_loop_id = nil
local pluck_loop_id = nil
local bell_loop_id = nil
local drift_loop_id = nil
local last_chime_hour = -1
local drone_drift_degree = 0

-- note names for the root pitch, C1 through D4 (covers the useful
-- 30-300hz drone range). standard equal temperament, A4 = 440hz.
local NOTE_NAMES = { "C", "C#", "D", "D#", "E", "F", "F#", "G", "G#", "A", "A#", "B" }
local note_options = {}
local note_freqs = {}
local default_note_index = 1
for midi = 24, 62 do
	local name = NOTE_NAMES[(midi % 12) + 1]
	local octave = math.floor(midi / 12) - 1
	table.insert(note_options, name .. octave)
	table.insert(note_freqs, 440 * (2 ^ ((midi - 69) / 12)))
	if midi == 36 then default_note_index = #note_options end   -- C2, ~65.4hz
end

-- ======= weather fetching (io.popen -> curl, no ssh/cron needed) =======
local function extract_number(s)
	if not s then return nil end
	local n = s:match("(-?%d+%.?%d*)")
	return n and tonumber(n) or nil
end

local function normalize_pressure(p)
	if p == nil then return 1013 end
	if p > 100 then return p else return p * 33.86 end
end

-- keep the most recent raw fetch and a short parsed-values summary
-- around so both can be inspected (hold K1 for a debug screen) --
-- since the parsed numbers are exactly what feeds the engine, if
-- something looks wrong on the main screen this shows whether it's a
-- open-meteo reporting quirk or a parsing bug here.
local last_raw_fetch = "none yet"
local last_parsed_summary = "no data yet"

-- pulls the FIRST "key": value (or "key":"value") match at or after
-- `from` out of the raw json text -- no library needed for a flat,
-- known schema like open-meteo's. `from` matters here because the
-- same key names appear twice: once in a *_units object (values are
-- unit strings like "°F", not numbers) and once in the real data
-- object -- always anchor `from` to the data object's own opening
-- brace, never search from the start of the whole response.
local function json_num(raw, key, from)
	local s, e = raw:find('"' .. key .. '"%s*:%s*"?', from or 1)
	if not s then return nil end
	return extract_number(raw:sub(e + 1, e + 16)), e
end

local function json_str(raw, key, from)
	local s, e = raw:find('"' .. key .. '"%s*:%s*"', from or 1)
	if not s then return nil end
	local val_end = raw:find('"', e + 1)
	if not val_end then return nil end
	return raw:sub(e + 1, val_end - 1)
end

local function split_json_str_array(s)
	local out = {}
	for item in (s or ""):gmatch('"([^"]*)"') do table.insert(out, item) end
	return out
end

local function split_json_num_array(s)
	local out = {}
	for item in (s or ""):gmatch('(-?%d+%.?%d*)') do table.insert(out, tonumber(item)) end
	return out
end

-- open-meteo's hourly block gives a "time" array of exact timestamps
-- (e.g. "2026-09-26T20:00") alongside a parallel "precipitation_
-- probability" array (0-100) -- find the entry whose hour matches
-- current.time exactly, no nearest-neighbor guessing needed.
local function precip_probability_now(raw, hourly_start, current_time)
	if not hourly_start or not current_time then return nil end
	local hour_prefix = current_time:sub(1, 13)   -- "YYYY-MM-DDTHH"
	local hourly_block = raw:sub(hourly_start)
	local time_list = hourly_block:match('"time"%s*:%s*%[(.-)%]')
	local prob_list = hourly_block:match('"precipitation_probability"%s*:%s*%[(.-)%]')
	local times = split_json_str_array(time_list)
	local probs = split_json_num_array(prob_list)
	for i, t in ipairs(times) do
		if t:sub(1, 13) == hour_prefix then return probs[i] end
	end
	return nil
end

local function fetch_weather()
	fetching = true
	local ok, raw = pcall(function()
		local f = io.popen(fetch_cmd())
		local result = f:read("*a")
		f:close()
		return result
	end)
	fetching = false

	if not ok or not raw or raw == "" then
		last_read_ok = false
		last_read_msg = "fetch failed -- check wifi"
		last_raw_fetch = "(fetch failed)"
		return
	end

	last_raw_fetch = raw:gsub("%s+", " "):sub(1, 400)

	-- anchor past the *_units objects, which repeat these same key
	-- names mapped to unit strings rather than the actual readings
	local current_start = raw:find('"current"%s*:%s*{')
	local hourly_start = raw:find('"hourly"%s*:%s*{')

	local current_time = json_str(raw, "time", current_start)
	local temp_f = json_num(raw, "temperature_2m", current_start)
	local humidity = json_num(raw, "relative_humidity_2m", current_start)
	local wind_mph = json_num(raw, "wind_speed_10m", current_start)
	local wind_deg = json_num(raw, "wind_direction_10m", current_start)
	local pressure_raw = json_num(raw, "pressure_msl", current_start)
	local current_precip_in = json_num(raw, "precipitation", current_start)
	local rain_chance = precip_probability_now(raw, hourly_start, current_time)

	-- the resolved lat/lon echo back at the top level -- since we send
	-- exact coordinates rather than a place name, this should always
	-- match what was requested; shown in the debug view as a sanity
	-- check that there's no geocoding step silently substituting it
	local resolved_lat = json_num(raw, "latitude")
	local resolved_lon = json_num(raw, "longitude")
	local resolved_tz = json_str(raw, "timezone")

	if temp_f and wind_mph and humidity and rain_chance then
		weather.temp_f = temp_f
		weather.wind_mph = wind_mph
		weather.humidity = humidity
		weather.pressure_hpa = normalize_pressure(pressure_raw)
		weather.precip_chance = rain_chance
		last_read_ok = true
		last_read_msg = "ok"
		last_parsed_summary = string.format(
			"%.3f,%.3f  %s  (" .. loc_note .. ")\n%.0fF  wind %.0fmph@%.0f  hum %.0f%%\nchance %.0f%%  now %.2fin  %.0fhPa",
			resolved_lat or 0, resolved_lon or 0, resolved_tz or "?",
			temp_f, wind_mph, wind_deg or -1, humidity, rain_chance, current_precip_in or 0, weather.pressure_hpa)
	else
		last_read_ok = false
		last_read_msg = "parse failed"
		last_parsed_summary = "(could not parse fields -- see raw below)"
	end

	-- also print the exact raw response to maiden's REPL, so it can be
	-- checked directly against open-meteo.com for the same coordinates
	-- -- the fastest way to confirm whether a surprising number is a
	-- fetch/parse bug here or just what the weather model is saying.
	print("bellweather raw fetch (truncated): " .. last_raw_fetch)
	print("bellweather parsed: " .. last_parsed_summary:gsub("\n", " / "))
end

-- ======= weather -> sound mapping =======
local function blended(v, default, influence)
	return default + (v - default) * influence
end

-- 0 (deep night) to 1 (midday), smooth cosine curve, peak ~1pm,
-- trough ~1am. based on the system clock, no network needed.
local function daytime_factor()
	local t = os.date("*t")
	local hour = t.hour + t.min / 60
	local angle = (hour - 13) / 24 * 2 * math.pi
	return (math.cos(angle) + 1) / 2
end

-- moon phase computed locally via simple synodic-month astronomy
-- rather than fetched -- this dropped the dependency on wttr.in's own
-- moon-day field (removed along with the rest of the old %-code fetch)
-- and is always available even if a fetch fails.
local SYNODIC_MONTH = 29.530588853
local KNOWN_NEW_MOON = os.time({ year = 2000, month = 1, day = 6, hour = 18, min = 14, sec = 0 })

local function moon_day()
	local days_since = (os.time() - KNOWN_NEW_MOON) / 86400
	return days_since % SYNODIC_MONTH
end

-- 0 (new moon) to 1 (full moon)
local function moon_intensity()
	local angle = (moon_day() / SYNODIC_MONTH) * 2 * math.pi
	return (1 - math.cos(angle)) / 2
end

-- manual overrides for testing/previewing weather-driven behavior
-- without waiting for real conditions. a forced value is used exactly
-- as set (bypassing the influence blend, since diluting a deliberate
-- test value back toward normal would defeat the point); "auto"
-- blends the real fetched value by the influence knob as usual.
local function get_temp()
	if params:get("temp_override") == 2 then return params:get("temp_forced") end
	local influence = params:get("influence") / 100
	return blended(weather.temp_f, 60, influence)
end

local function get_wind()
	if params:get("wind_override") == 2 then return params:get("wind_forced") end
	local influence = params:get("influence") / 100
	return blended(weather.wind_mph, 3, influence)
end

local function get_humidity()
	if params:get("humidity_override") == 2 then return params:get("humidity_forced") end
	local influence = params:get("influence") / 100
	return blended(weather.humidity, 50, influence)
end

-- returns 0..1 (a fraction, not a percent) -- everywhere downstream
-- (melody density/spacing, noise amount) already expects that 0..1
-- scale, so precip_chance (0..100, a % chance of rain/snow) is
-- normalized here and nowhere else needs to change.
local function get_precip()
	if params:get("precip_amt_override") == 2 then return params:get("precip_amt_forced") / 100 end
	local influence = params:get("influence") / 100
	return blended(weather.precip_chance, 0, influence) / 100
end

local function apply_weather()
	local temp_f = get_temp()
	local wind = get_wind()
	local humid = get_humidity()
	local precip = get_precip()

	-- temperature now drives the drone's stochastic drift instead of
	-- cutoff (see drone_drift_interval() below) -- cutoff stays at a
	-- fixed, sensible baseline, still adjustable via the E2 push override
	local cutoff_base = 1400
	engine.cutoff(util.clamp(cutoff_base + push_cutoff, 100, 7000))

	-- wind -> lfo rate driving cutoff sweeps: gustier = faster, but kept
	-- slow overall. previous range topped out at 0.25hz (a 4s cycle) and
	-- the push override could add up to 0.6hz (under 2s -- audibly a
	-- "swirl" close to 1 cycle/sec) -- cut both substantially so even at
	-- max wind + max push this can't get anywhere near that fast again.
	local lfoRate_base = util.linlin(util.clamp(wind, 0, 50), 0, 50, 0.006, 0.05)
	engine.lfoRate(util.clamp(lfoRate_base + push_lfoRate, 0.004, 0.09))

	-- humidity (cloudiness proxy) -> resonance, kept modest so the
	-- filter stays clean rather than honky/nasal at high humidity
	local resonance_base = util.linlin(util.clamp(humid, 0, 100), 0, 100, 0.05, 0.3)
	engine.resonance(util.clamp(resonance_base + push_resonance, 0.0, 0.7))

	-- precipitation -> noise amount, kept subtle/textural
	engine.noiseAmt(util.linlin(util.clamp(precip, 0, 1.0), 0, 1.0, 0, 0.3))

	-- time of day -> octave/harmonic spread (handled entirely in the
	-- engine); not weather data, so not affected by the influence knob
	engine.daytime(daytime_factor())

	-- wind -> amplitude-swell lfo rate multiplier, across all octave
	-- layers. kept modest so even gusty conditions stay slow and calm.
	engine.ampLfoMult(util.linlin(util.clamp(wind, 0, 50), 0, 50, 0.6, 1.7))

	-- moon phase -> occasional low-end throb depth/frequency (handled
	-- in the engine); not weather data, so not affected by influence
	engine.moonThrob(moon_intensity())

	-- humidity -> glide time for the drone's drift steps: drier air
	-- glides quickly, humid air feels thicker and glides slowly. widened
	-- so octave-spanning moves (see drone_drift_freq) always feel like a
	-- long, graceful portamento rather than a quick slide.
	engine.glideTime(util.linlin(util.clamp(humid, 0, 100), 0, 100, 4, 26))

	-- wind -> mix amount for the 4-band modulated noise layer. widened
	-- now that the default noise_level baseline is low (0.1) -- wind
	-- speed needs real range to still be clearly audible on top of it.
	engine.windNoiseMix(util.linlin(util.clamp(wind, 0, 50), 0, 50, 0, 1.0))

	-- raw wind speed, so the wind-noise layer's own internal lfo-rate
	-- range can depend on it directly (handled in the engine)
	engine.windSpeed(util.clamp(wind, 0, 50))
end

local function apply_pitch()
	-- changing root resets the drift back to exactly that note; drift
	-- then resumes wandering from the new home
	drone_drift_degree = 0
	engine.pitch(note_freqs[params:get("root_note")])
end

-- deep bell strike, tied to the current root note (an octave up from
-- the drone fundamental, a more natural register for a bell)
local function bell_freq()
	return note_freqs[params:get("root_note")] * 2
end

-- independent user levels for the three sound sources: drone
-- (oscillator layers), noise (precipitation texture + wind bands),
-- and the precipitation-driven pluck voice. not weather-driven --
-- plain user balance controls.
local function apply_levels()
	engine.droneLevel(params:get("drone_level"))
	engine.noiseLevel(params:get("noise_level"))
end

-- ======= precipitation type: auto-detect, or manual override =======
local function is_snowing()
	local mode = params:get("precip_mode")
	if mode == 2 then return false end   -- force rain
	if mode == 3 then return true end    -- force snow
	return get_temp() <= 32              -- auto: simple freezing-point heuristic
end

-- ======= melody: precipitation-driven, synapse-like mutating pluck =======
-- roams a couple octaves above the drone root so it rides on top
-- rather than competing with the fundamental. scale is user-selectable.
local SCALE_NAMES = { "major pentatonic", "minor pentatonic", "major",
	"natural minor", "dorian", "whole tone" }
local SCALES = {
	{ 0, 2, 4, 7, 9 },              -- major pentatonic
	{ 0, 3, 5, 7, 10 },             -- minor pentatonic
	{ 0, 2, 4, 5, 7, 9, 11 },       -- major
	{ 0, 2, 3, 5, 7, 8, 10 },       -- natural minor
	{ 0, 2, 3, 5, 7, 9, 10 },       -- dorian
	{ 0, 2, 4, 6, 8, 10 },          -- whole tone
}
local current_degree = 0

local function melody_freq(degree)
	local scale = SCALES[params:get("melody_scale")]
	local scale_len = #scale
	local octave = math.floor(degree / scale_len)
	local idx = (degree % scale_len) + 1
	local semitones = scale[idx] + (octave * 12)
	local root_freq = note_freqs[params:get("root_note")]
	return root_freq * 4 * (2 ^ (semitones / 12))
end

-- drone drift: the fundamental slowly, stochastically wanders to
-- nearby scale degrees (same scale as the precip synth) and glides
-- there rather than jumping. temperature governs how often it steps;
-- humidity (in apply_weather) governs how slowly it glides once it
-- does. bounded so it can't wander indefinitely far from home.
local function drone_drift_freq(degree)
	local scale = SCALES[params:get("melody_scale")]
	local scale_len = #scale
	local octave = math.floor(degree / scale_len)
	local idx = (degree % scale_len) + 1
	local semitones = scale[idx] + (octave * 12)
	local root_freq = note_freqs[params:get("root_note")]
	return root_freq * (2 ^ (semitones / 12))
end

-- humidity governs how often the drone drifts: muggier air moves more
-- restlessly, drier air settles for longer. hard floor at 30s no matter
-- how humid it gets -- this is a slow, occasional wander, never a fidget.
-- E2 now scales the global tempo (params:delta("clock_tempo", d)); the
-- precip melody's clock.sync() timing already tracks that automatically,
-- but this drift timer runs on wall-clock clock.sleep(), so it needs an
-- explicit scale factor to slow down/speed up along with everything else.
-- 0.5 sec/beat == 120bpm is the reference point (scale factor 1.0).
local function tempo_scale()
	return clock.get_beat_sec() / 0.5
end

local function drone_drift_interval()
	local humid = get_humidity()
	local raw_interval = util.linlin(util.clamp(humid, 0, 100), 0, 100, 90, 30)
	return math.max(30, raw_interval) * tempo_scale()
end

-- steps mostly by a full scale-octave (so the drone actually lands on
-- low-octave anchors, e.g. root=C2 -> wanders between roughly C1, C2,
-- C3), with occasional smaller in-scale steps for variety. bounded to
-- one octave above/below root so it stays in the low, meditative range
-- rather than wandering arbitrarily far.
local function mutate_drone_drift()
	local scale_len = #SCALES[params:get("melody_scale")]
	local step
	if math.random() < 0.5 then
		step = (math.random(0, 1) == 1) and scale_len or -scale_len
	else
		local dir = (math.random(0, 1) == 1) and 1 or -1
		step = dir * math.random(1, 2)
	end
	drone_drift_degree = util.clamp(drone_drift_degree + step, -scale_len, scale_len)
end

-- signed size of the last move (0 = the last step was a held/repeated
-- note) -- feeds the leap-recovery bias in mutate_degree() below
local last_move = 0

-- a plain unbiased random walk wanders aimlessly and never resolves
-- anywhere, which doesn't read as a melody. this leans on three
-- ordinary melody-writing habits instead, while staying just as
-- stochastic overall:
--   - motion is mostly by step, occasionally by leap, weighted so
--     small movement is far more common than large jumps
--   - a leap tends to be followed by stepwise motion back the other
--     way (leap recovery), rather than another leap in the same
--     direction, which is what keeps a real melody from just
--     rocketing off in one direction
--   - a gentle pull back toward the home degree (0) that strengthens
--     the further out it wanders, so it keeps circling a center
--     instead of drifting forever -- plus an occasional held/repeated
--     note, since real phrases breathe rather than moving every beat
local function mutate_degree()
	if math.random() < 0.15 then
		last_move = 0
		return
	end

	local size_roll = math.random()
	local size
	if size_roll < 0.65 then size = 1
	elseif size_roll < 0.88 then size = 2
	else size = math.random(3, 4) end

	local dir
	if math.abs(last_move) >= 3 and math.random() < 0.7 then
		dir = (last_move > 0) and -1 or 1
	else
		local toward_center = (current_degree > 0) and -1 or 1
		local center_pull = util.clamp(math.abs(current_degree) / 14, 0, 1) * 0.6
		dir = (math.random() < (0.5 + center_pull)) and toward_center or -toward_center
	end

	-- bounded random walk -- without this, current_degree could drift
	-- unbounded over long runtimes until melody_freq() produced
	-- frequencies outside the pluck voice's usable range (its delay
	-- line has a fixed minimum around 20hz), silencing it entirely
	-- while the grid visuals kept working fine (they only depend on
	-- the bounded column position, not the actual frequency)
	current_degree = util.clamp(current_degree + (dir * size), -14, 14)
	last_move = dir * size
end

-- density: probability of a note firing on each clock tick, from
-- precipitation amount, blended by influence, always kept sparse
-- precip amount now governs both dimensions of density, not just a
-- probability on a fixed fast grid (which read as a hard on/off
-- threshold): the actual TIME BETWEEN checks widens or narrows with
-- precip amount, and the probability of a note firing at each check
-- also scales -- together giving genuinely sparse-to-dense spacing
-- rather than a fixed-rate coin flip.
-- any nonzero rain should audibly start the melody right away, rather
-- than fading in imperceptibly -- so both step spacing and density
-- jump to a solidly audible floor the instant precip > 0, then keep
-- scaling up smoothly from there as the amount increases
-- musically-related step multipliers rather than one fixed subdivision
-- -- picking a new one each step (weighted toward "plain" values, with
-- occasional short/long outliers) keeps the AVERAGE spacing tied to
-- precip amount while breaking the rigid, metronomic quarter-note grid
-- a single fixed clock.sync() value always produces.
local STEP_MULTIPLIERS = { 0.5, 0.67, 0.75, 1.0, 1.0, 1.0, 1.33, 1.5, 2.0 }

local function pluck_step_beats()
	local precip = get_precip()
	if precip <= 0 then return 4.0 end
	local base = util.linlin(util.clamp(precip, 0.001, 1.0), 0.001, 1.0, 2.5, 0.4)
	local mult = STEP_MULTIPLIERS[math.random(#STEP_MULTIPLIERS)]
	return base * mult
end

local function pluck_density()
	local precip = get_precip()
	if precip <= 0 then return 0 end
	return util.linlin(util.clamp(precip, 0.001, 1.0), 0.001, 1.0, 0.4, 0.85)
end

-- rain: snappy (fast attack, quick decay). snow: gentler (soft attack,
-- longer decay). switches whenever rain/snow status changes. no filter
-- (LPF/cutoff) is applied to these notes at all anymore -- coef and
-- decaytime alone shape the tone, so nothing here or in the drone's
-- own filter sweep can color or dull the precip synth's sound.
local function apply_pluck_character()
	if is_snowing() then
		engine.pluckStrike(0.09)
		engine.pluckDecay(2.8)
		engine.pluckCoef(0.22)
	else
		engine.pluckStrike(0.002)
		engine.pluckDecay(0.5)
		engine.pluckCoef(0.1)
	end
	-- precip amount also scales note amplitude, not just density: a
	-- light drizzle plucks quietly, a heavier fall plucks fuller
	local precip_amp_factor = util.linlin(util.clamp(get_precip(), 0, 1.0), 0, 1.0, 0.5, 1.0)
	engine.pluckAmp(0.28 * params:get("precip_synth_level") * precip_amp_factor)
end

-- ======= grid: melody-triggered drops rolling down (rain), or gentle
-- accumulating flakes (snow) =======
local GRID_W, GRID_H = 16, 8
local grid_time = 0
local drops = {}
local snow_accum = {}
for i = 1, GRID_W do snow_accum[i] = 0 end
local wave_phase = 0

-- gentle background wave, present even with no precipitation at all --
-- a slow left-to-right sweep of brightness bands, so the grid isn't
-- just dark and empty when it's dry. simplified from an earlier
-- wind-direction-projected version, which never read clearly as
-- "wind" -- a plain left-to-right sweep is a much more legible motif.
-- speed still scales with wind (calm air barely moves it, gusty
-- conditions noticeably faster), but stays slow even at the top end.
local function update_wave(dt)
	local wind = get_wind()
	local rate = util.linlin(util.clamp(wind, 0, 50), 0, 50, 0.01, 0.12)
	wave_phase = wave_phase + (rate * dt)
end

local function degree_to_column(degree)
	-- wraps the melody's roaming range across the grid width
	local col = 1 + ((degree * 3) % GRID_W)
	return util.clamp(math.floor(col), 1, GRID_W)
end

local function spawn_grid_drop(degree)
	table.insert(drops, { x = degree_to_column(degree), y = 1 })
end

local function update_drops(dt)
	local snowing = is_snowing()
	local fall_speed = snowing and 0.5 or 5.0   -- rows/sec
	grid_time = grid_time + dt

	for i = #drops, 1, -1 do
		local d = drops[i]
		d.y = d.y + fall_speed * dt
		if snowing then
			d.x = d.x + math.sin(grid_time * 0.6 + d.y) * 0.015
		else
			d.x = d.x + math.sin(d.y * 2.2) * 0.06   -- rolling-down-glass wobble
		end

		local col = util.clamp(math.floor(d.x + 0.5), 1, GRID_W)
		local landing_row = GRID_H - snow_accum[col]

		if d.y >= landing_row then
			if snowing then
				snow_accum[col] = math.min(snow_accum[col] + 1, GRID_H - 1)
			end
			table.remove(drops, i)
		end
	end

	-- slow, occasional melt, so accumulation never just fills forever
	if math.random() < (0.4 * dt / 25) then
		local col = math.random(1, GRID_W)
		if snow_accum[col] > 0 then snow_accum[col] = snow_accum[col] - 1 end
	end
end

local function grid_redraw()
	g:all(0)

	local day_brightness = 0.6 + (daytime_factor() * 0.4)
	local snowing = is_snowing()

	-- gentle background wave: vertical bands of brightness sweeping
	-- straight left to right (column position only -- no row/direction
	-- math), deliberately dim so it never competes with drops/snow above
	local for_col = {}
	for x = 1, GRID_W do
		-- minus wave_phase (not plus) so the bright band's position
		-- moves toward larger x as time passes -- i.e. left to right
		local wave = (math.sin(x * 0.35 - wave_phase) + 1) / 2
		for_col[x] = math.floor(wave * 3 * day_brightness)
	end
	for x = 1, GRID_W do
		local lvl = for_col[x]
		if lvl > 0 then
			for y = 1, GRID_H do g:led(x, y, lvl) end
		end
	end

	-- accumulated snow pile, brightest near the top of the pile
	if snowing then
		for col = 1, GRID_W do
			for h = 1, snow_accum[col] do
				local row = GRID_H - h + 1
				local lvl = (h == snow_accum[col]) and 10 or 4
				g:led(col, row, util.clamp(math.floor(lvl * day_brightness), 0, 15))
			end
		end
	end

	-- falling drops / flakes, with a short fading trail for rain
	for _, d in ipairs(drops) do
		local yi = util.clamp(math.floor(d.y + 0.5), 1, GRID_H)
		local xi = util.clamp(math.floor(d.x + 0.5), 1, GRID_W)
		if snowing then
			g:led(xi, yi, util.clamp(math.floor(9 * day_brightness), 0, 15))
		else
			g:led(xi, yi, util.clamp(math.floor(15 * day_brightness), 0, 15))
			local ty = util.clamp(math.floor(d.y - 1 + 0.5), 1, GRID_H)
			if ty ~= yi then
				g:led(xi, ty, util.clamp(math.floor(6 * day_brightness), 0, 15))
			end
		end
	end

	g:refresh()
end

-- changing location re-reads the weather once things settle (encoder
-- turns on lat/lon fire many actions; only the last one fetches). does
-- nothing during init's params:bang(), the fetch loop handles that.
local started = false
local refetch_id = nil
local function refetch_soon()
	if not started then return end
	if refetch_id then clock.cancel(refetch_id) end
	refetch_id = clock.run(function()
		clock.sleep(1.5)
		refetch_id = nil
		fetch_weather()
		apply_weather()
		apply_pluck_character()
		screen_dirty = true
	end)
end

-- ======= init =======
function init()
	params:add_separator("Bell Weather")

	-- where the weather comes from; see current_latlon()
	params:add{ type = "option", id = "location", name = "location",
		options = { "auto (network)", "Watertown, MA", "custom" }, default = 1,
		action = function() refetch_soon() end }
	params:add{ type = "control", id = "latitude", name = "latitude",
		controlspec = controlspec.new(-90, 90, "lin", 0.01, HOME_LAT, "°"),
		action = function() if params:get("location") == 3 then refetch_soon() end end }
	params:add{ type = "control", id = "longitude", name = "longitude",
		controlspec = controlspec.new(-180, 180, "lin", 0.01, HOME_LON, "°"),
		action = function() if params:get("location") == 3 then refetch_soon() end end }

	-- root note is a set-once EDIT parameter, not a live performance
	-- control -- default is A1, a low, meditative drone-bell fundamental
	params:add{ type = "option", id = "root_note", name = "root note",
		options = note_options, default = default_note_index,
		action = function() apply_pitch() end }

	-- manual override for testing/previewing the melody voice without
	-- waiting for real precipitation
	params:add{ type = "option", id = "precip_mode", name = "precip mode",
		options = { "auto", "force rain", "force snow" }, default = 1,
		action = function() apply_pluck_character() end }

	params:add{ type = "option", id = "melody_scale", name = "synth scale",
		options = SCALE_NAMES, default = 1 }

	params:add{ type = "option", id = "hourly_bell", name = "hourly bell",
		options = { "on", "off" }, default = 1 }

	-- manual overrides for temp/wind/humidity/precip amount, so any
	-- weather-driven behavior can be tested without waiting for real
	-- conditions. each pairs an auto/forced toggle with a forced-value
	-- control; the toggle only matters when set to "forced".
	params:add{ type = "option", id = "temp_override", name = "temp override",
		options = { "auto", "forced" }, default = 1,
		action = function() apply_weather(); apply_pluck_character() end }
	params:add{ type = "control", id = "temp_forced", name = "temp force",
		controlspec = controlspec.new(-10, 105, "lin", 0, 60, "F"),
		action = function() apply_weather(); apply_pluck_character() end }

	params:add{ type = "option", id = "wind_override", name = "wind override",
		options = { "auto", "forced" }, default = 1,
		action = function() apply_weather() end }
	params:add{ type = "control", id = "wind_forced", name = "wind force",
		controlspec = controlspec.new(0, 50, "lin", 0, 15, "mph"),
		action = function() apply_weather() end }

	params:add{ type = "option", id = "humidity_override", name = "humid override",
		options = { "auto", "forced" }, default = 1,
		action = function() apply_weather() end }
	params:add{ type = "control", id = "humidity_forced", name = "humid force",
		controlspec = controlspec.new(0, 100, "lin", 0, 50, "%"),
		action = function() apply_weather() end }

	params:add{ type = "option", id = "precip_amt_override", name = "rain chance ovr",
		options = { "auto", "forced" }, default = 1,
		action = function() apply_weather() end }
	params:add{ type = "control", id = "precip_amt_forced", name = "rain chance frc",
		controlspec = controlspec.new(0, 100, "lin", 0, 0, "%"),
		action = function() apply_weather() end }

	-- independent levels for the three sound sources, plain user
	-- balance controls, not weather-driven
	local cs_level = controlspec.new(0, 1.5, "lin", 0, 1.0, "")
	local cs_noise_level = controlspec.new(0, 1.5, "lin", 0, 0.1, "")
	params:add{ type = "control", id = "drone_level", name = "drone level",
		controlspec = cs_level, action = function() apply_levels() end }
	params:add{ type = "control", id = "noise_level", name = "noise level",
		controlspec = cs_noise_level, action = function() apply_levels() end }
	params:add{ type = "control", id = "precip_synth_level", name = "synth level",
		controlspec = cs_level, action = function() apply_pluck_character() end }

	params:add{ type = "number", id = "influence", name = "influence",
		min = 0, max = 100, default = 100,
		formatter = function(p) return p:get() .. "%" end,
		action = function() apply_weather() end }

	local cs_amp = controlspec.new(0, 1.0, "lin", 0, 0.5, "")
	params:add{ type = "control", id = "amp", name = "output level",
		controlspec = cs_amp,
		action = function(x) if not muted then engine.amp(x) end end }

	local cs_fx_mix = controlspec.new(0, 1.0, "lin", 0, 0.15, "")
	params:add{ type = "control", id = "fx_mix", name = "reverb+delay mix",
		controlspec = cs_fx_mix,
		action = function(x) engine.fxMix(x) end }

	params:bang()
	apply_pitch()
	apply_weather()
	apply_pluck_character()
	apply_levels()

	-- a single deep bell strike to kick things off
	engine.bellStrike(bell_freq())

	started = true
	fetch_loop_id = clock.run(function()
		while true do
			fetch_weather()
			apply_weather()
			apply_pluck_character()
			screen_dirty = true
			if last_read_ok then
				clock.sleep(600)
			else
				clock.sleep(20)
			end
		end
	end)

	anim_loop_id = clock.run(function()
		local dt = 1 / 20
		while true do
			clock.sleep(dt)
			update_wave(dt)
			update_drops(dt)
			grid_redraw()
			redraw()
		end
	end)

	-- melody sequencer: clock-synced "click" grid, with the probability
	-- of a note firing on each tick driven by precipitation density
	pluck_loop_id = clock.run(function()
		while true do
			local precip = get_precip()
			if precip <= 0 then
				clock.sync(4)   -- dry: idle, no notes at all
			else
				clock.sync(pluck_step_beats())
				if not muted and math.random() < pluck_density() then
					mutate_degree()
					engine.pluck(melody_freq(current_degree))
					spawn_grid_drop(current_degree)
				end
			end
		end
	end)

	-- one bell chime on the hour, unless turned off in EDIT
	last_chime_hour = os.date("*t").hour
	bell_loop_id = clock.run(function()
		while true do
			clock.sleep(20)
			local t = os.date("*t")
			if t.min == 0 and t.hour ~= last_chime_hour then
				last_chime_hour = t.hour
				if params:get("hourly_bell") == 1 and not muted then
					engine.bellStrike(bell_freq())
				end
			end
		end
	end)

	-- drone drift: humidity-timed (min 30s), octave-spanning steps to
	-- nearby scale degrees; the engine's own glide (also humidity-
	-- governed, and widened) does the actual long portamento between steps
	drift_loop_id = clock.run(function()
		while true do
			clock.sleep(drone_drift_interval())
			mutate_drone_drift()
			engine.pitch(drone_drift_freq(drone_drift_degree))
		end
	end)
end

-- ======= keys =======
-- K2 alone: mute. K3 alone: fetch weather now.
-- K1 held + K2: cycle which parameter K1+E2 pushes (cutoff/resonance/lfo rate).
-- K1 held + K3: snap all push offsets back to zero (pure weather-governed).
function key(n, z)
	if n == 1 then
		k1_held = (z == 1)
	elseif n == 2 and z == 1 then
		if k1_held then
			push_mode = (push_mode % 3) + 1
		else
			muted = not muted
			engine.amp(muted and 0 or params:get("amp"))
		end
	elseif n == 3 and z == 1 then
		if k1_held then
			push_cutoff = 0
			push_resonance = 0
			push_lfoRate = 0
			apply_weather()
		else
			clock.run(function()
				fetch_weather()
				apply_weather()
			end)
		end
	end
end

-- E2: plain turn = global tempo (speeds up/slows down the whole thing
-- proportionally -- the precip melody's clock.sync() timing and the
-- humidity-timed drone drift both track clock_tempo). K1-held turn =
-- the old manual push override (cutoff/resonance/lfo rate nudge).
-- E3: plain turn = reverb+delay mix. K1-held turn = output level.
function enc(n, d)
	if n == 1 then params:delta("influence", d)
	elseif n == 2 then
		if k1_held then
			if push_mode == 1 then
				push_cutoff = util.clamp(push_cutoff + d * 20, -1500, 1500)
			elseif push_mode == 2 then
				push_resonance = util.clamp(push_resonance + d * 0.005, -0.25, 0.25)
			else
				push_lfoRate = util.clamp(push_lfoRate + d * 0.0008, -0.04, 0.04)
			end
			apply_weather()
		else
			params:delta("clock_tempo", d)
		end
	elseif n == 3 then
		if k1_held then
			params:delta("amp", d)
		else
			params:delta("fx_mix", d)
		end
	end
end

-- ======= screen =======
local function icon_thermometer(x, y, hot)
	screen.level(hot and 12 or 8)
	screen.move(x, y - 5); screen.line(x, y + 3); screen.stroke()
	screen.circle(x, y + 4, 2); screen.fill()
end

local function icon_wind(x, y, strong)
	screen.level(strong and 12 or 8)
	for i = 0, 2 do
		local yy = y - 3 + i * 3
		screen.move(x - 5, yy)
		screen.line(x + 4 + (i == 1 and 2 or 0), yy)
		screen.stroke()
	end
end

local function icon_droplet(x, y, heavy)
	screen.level(heavy and 12 or 6)
	screen.move(x, y - 5); screen.line(x - 3, y + 2); screen.line(x + 3, y + 2); screen.line(x, y - 5)
	screen.stroke()
	screen.circle(x, y + 2, 3); screen.fill()
end

local function icon_cloud(x, y, dense)
	screen.level(dense and 12 or 6)
	screen.circle(x - 3, y, 3); screen.circle(x + 1, y - 2, 4); screen.circle(x + 5, y, 3)
	screen.fill()
end

-- word-wraps a long string across several screen lines starting at
-- (x, y), advancing by line_h per line -- used for the raw-fetch debug
-- view, since the json reply can be longer than the screen is wide
-- respects embedded "\n" as real line breaks (wrapping each piece
-- independently), rather than flattening them into one run-on line
local function wrapped_text(str, x, y, line_h, max_chars)
	for piece in (str .. "\n"):gmatch("(.-)\n") do
		local line_start = 1
		if #piece == 0 then
			y = y + line_h
		end
		while line_start <= #piece do
			local line_end = math.min(line_start + max_chars - 1, #piece)
			screen.move(x, y)
			screen.text(piece:sub(line_start, line_end))
			y = y + line_h
			line_start = line_end + 1
		end
	end
	return y
end

function redraw()
	screen.clear()

	if k1_held then
		-- debug view: the parsed values actually feeding the engine
		-- (check these against a weather app for your exact spot), plus
		-- a raw snippet of the open-meteo json underneath as a second check
		screen.level(15)
		screen.move(0, 7); screen.text("weather debug")
		screen.level(6)
		screen.move(0, 16)
		screen.text(last_read_ok and "last read: ok" or ("last read: " .. last_read_msg))
		screen.level(12)
		local y = wrapped_text(last_parsed_summary, 0, 26, 8, 36)
		screen.level(3)
		screen.move(0, y + 2)
		screen.text("raw json:")
		screen.level(6)
		wrapped_text(last_raw_fetch:sub(1, 90), 0, y + 10, 7, 42)
		screen.update()
		return
	end

	screen.level(muted and 4 or 15)
	screen.move(0, 7); screen.text("Bell Weather")
	screen.level(4)
	screen.move(128, 7)
	screen.text_right(fetching and "fetching..." or (muted and "muted" or "playing"))

	if not last_read_ok then
		screen.level(4)
		screen.move(0, 16)
		screen.text(last_read_msg)
	end

	local cols = { 12, 44, 76, 108 }
	local y_icon = 26
	icon_thermometer(cols[1], y_icon, weather.temp_f > 70)
	icon_wind(cols[2], y_icon, weather.wind_mph > 15)
	icon_cloud(cols[3], y_icon, weather.humidity > 60)
	icon_droplet(cols[4], y_icon, weather.precip_chance > 40)

	screen.level(10)
	screen.move(cols[1] - 8, 40); screen.text(string.format("%.0fF", weather.temp_f))
	screen.move(cols[2] - 10, 40); screen.text(string.format("%.0fmph", weather.wind_mph))
	screen.move(cols[3] - 8, 40); screen.text(string.format("%.0f%%", weather.humidity))
	screen.move(cols[4] - 8, 40); screen.text(string.format("%.0f%%", weather.precip_chance))

	screen.level(4)
	screen.move(0, 50)
	screen.text(string.format("root: %s (%.0fhz)",
		note_options[params:get("root_note")], note_freqs[params:get("root_note")]))

	local pushed = (push_cutoff ~= 0) or (push_resonance ~= 0) or (push_lfoRate ~= 0)
	screen.level(k1_held and 8 or 3)
	screen.move(0, 57)
	if k1_held then
		screen.text(string.format("K1+E2: %s%s  K1+E3: amp",
			PUSH_NAMES[push_mode], pushed and " *" or ""))
	else
		screen.text(string.format("tempo: %.0f  fx: %.0f%%",
			params:get("clock_tempo"), params:get("fx_mix") * 100))
	end

	screen.level(4)
	screen.move(0, 63)
	screen.text(muted and "-- muted --" or (is_snowing() and "-- snow --" or "-- rain --"))

	screen.update()
end

function cleanup()
	if fetch_loop_id then clock.cancel(fetch_loop_id) end
	if anim_loop_id then clock.cancel(anim_loop_id) end
	if pluck_loop_id then clock.cancel(pluck_loop_id) end
	if bell_loop_id then clock.cancel(bell_loop_id) end
	if drift_loop_id then clock.cancel(drift_loop_id) end
end
