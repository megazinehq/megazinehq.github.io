# Bell Weather

A norns script: a slow, subtractive drone bell played by the weather outside, with rain and snow plucking a melody over it. Grid optional.

- temperature → filter cutoff
- wind → LFO rate, and the direction and speed notes drift across the grid
- humidity → resonance
- chance of rain or snow → noise and how often the melody plays
- moon phase → an occasional slow low throb
- time of day → octave and harmonic spread (fuller by day, darker at night)

Weather comes from open-meteo.com every ten minutes. No API key needed; norns just needs to be on wifi.

## Install

**From maiden:** unzip so the folder is `dust/code/bellweather/` (containing `bellweather.lua` and `lib/Engine_WeatherBell.sc`). Upload it through maiden's file browser, or copy it over with `scp -r bellweather we@norns.local:dust/code/`.

**First run:** the script brings its own SuperCollider engine, so after installing, go to **SYSTEM > RESTART** once before loading it.

## Where the weather comes from

PARAMS > EDIT > **location**:

- **auto (network)**: looks up roughly where your norns is from its internet connection, once per launch. This is the default.
- **Watertown, MA**: where it was made.
- **custom**: set **latitude** and **longitude** just below.

The debug screen shows which coordinates it used.

## Controls

- E1: weather influence
- E2: tempo
- E3: reverb + delay mix
- K2: mute / unmute
- K3: fetch the weather now
- K1 + E2: push cutoff / resonance / LFO past the weather's value
- K1 + E3: output level
- K1 + K2: choose which one K1 + E2 pushes
- K1 + K3: reset the pushes

PARAMS > EDIT also has the root note, a rain/snow preview, the melody scale, the hourly bell, per-weather overrides for testing, and levels.

## License

GPL-3.0. See `LICENSE`.

Part of [megaZINE](https://megazine.org/).
